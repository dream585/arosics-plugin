=====
Usage
=====

To use GeoArray in a project::

    import geoarray
