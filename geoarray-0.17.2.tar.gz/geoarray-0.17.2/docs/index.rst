Welcome to GeoArray's documentation!
====================================

Contents:

.. toctree::
   :maxdepth: 4

   readme
   installation
   usage
   contributing
   authors
   history

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
