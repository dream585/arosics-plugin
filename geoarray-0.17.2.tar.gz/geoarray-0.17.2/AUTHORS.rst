=======
Credits
=======

Development Lead
----------------

* Daniel Scheffler <danschef@gfz-potsdam.de>
** <https://www.gfz-potsdam.de/staff/daniel.scheffler/sec14/>


Contributors
------------

* Jessica Palka <jessica.palka@gfz-potsdam.de>

